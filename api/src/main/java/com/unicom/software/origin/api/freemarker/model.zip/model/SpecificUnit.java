package com.chinaunicom.software.origin.api.freemarker.model;

import java.util.List;

public class SpecificUnit {
    private String id;
    private String specificBase;
    private String relativeNode;
    private String relativePath;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSpecificBase() {
        return specificBase;
    }

    public void setSpecificBase(String specificBase) {
        this.specificBase = specificBase;
    }

    private List<Specific> specificList;

    public String getRelativeNode() {
        return relativeNode;
    }

    public void setRelativeNode(String relativeNode) {
        this.relativeNode = relativeNode;
    }

    public String getRelativePath() {
        return relativePath;
    }

    public void setRelativePath(String relativePath) {
        this.relativePath = relativePath;
    }

    public List<Specific> getSpecificList() {
        return specificList;
    }

    public void setSpecificList(List<Specific> specificList) {
        this.specificList = specificList;
    }
}
