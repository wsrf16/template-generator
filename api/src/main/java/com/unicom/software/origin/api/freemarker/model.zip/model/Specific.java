package com.chinaunicom.software.origin.api.freemarker.model;

public class Specific {
    private String name;
    private String format;
    private String template;
    private String className;
    private String fileName;
    private String relativeNode;
    private String relativePath;




    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getRelativeNode() {
        return relativeNode;
    }

    public void setRelativeNode(String relativeNode) {
        this.relativeNode = relativeNode;
    }

    public String getRelativePath() {
        return relativePath;
    }

    public void setRelativePath(String relativePath) {
        this.relativePath = relativePath;
    }
}
